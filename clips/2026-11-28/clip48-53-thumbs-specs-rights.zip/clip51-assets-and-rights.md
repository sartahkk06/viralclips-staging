# clip51 assets and rights (situation, Hindi animated)

| Asset | Source | License | Status |
|---|---|---|---|
| Animation (characters, icons, backgrounds) | drawn in code by tools/hindi_anim.py | original, owned by channel | PASS |
| Script, captions, on-screen text | written for this channel | original | PASS |
| Hindi voice | SYSPIN Hindi male VITS, SPIRE Lab, IISc Bengaluru (huggingface.co/SYSPIN/tts_vits_coquiai_HindiMale); README license checked by tools/setup.sh on 28 Nov 2026 | CC BY 4.0, credited in description | PASS |
| Font | Poppins | SIL OFL | PASS |
| Music / SFX | none | n/a | PASS |
| Photos / footage / logos | none | n/a | PASS |

Facts: sancharsaathi.gov.in CEIR services page + CEIR Mobile User Manual v02 (read 28 Nov 2026).
Joke/puzzle content check: clean, no religion, caste, region, gender stereotypes, body shaming, disability or real people.
Copyright check: PASS
